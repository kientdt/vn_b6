<!--
Hi there - thanks for filling an issue. Please ensure the following things before creating an issue - thank you! 🤓

- Check the repository. Please only create issue here that concern the Zammad Docker setup. Use the other repositories for other issues.
- Make sure to use the latest version of Zammads Docker containers via: docker-compose pull
- Please write the issue in english

* The upper textblock will be removed automatically when you submit your issue *
-->

# Infos

* Docker version:
* Docker-compose version:
* Operating system (Docker host):

# Expected behavior

*

# Actual behavior

*

# Steps to reproduce the behavior

*
