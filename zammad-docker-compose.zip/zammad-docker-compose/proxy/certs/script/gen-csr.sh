#!/bin/bash
openssl req -newkey rsa:4096 -nodes -sha256 -keyout logging.k8s.vnpt.vn.key -out logging.k8s.vnpt.vn.csr
