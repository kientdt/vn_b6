#!/bin/bash
sudo openssl x509 -req -days 3650 -in logging.k8s.vnpt.vn.csr -CA ca.crt -CAkey ca.key -CAcreateserial -out logging.k8s.vnpt.vn.crt
